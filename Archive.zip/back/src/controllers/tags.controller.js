const { responseHandler, asyncHandler } = require('../helpers');
// const { tagsService } = require('../services');

// exports.getTags = asyncHandler(async (req, res) => {
//   try {
//     await tagsService.retrieveAll((err, data) => {
//       if (err) {
//         console.log(err);
//         return res.status(err.code).json(err);
//       }
//       return res.status(data.code).json(data);
//     });
//   } catch (err) {
//     console.log(err);
//     return res
//       .status(500)
//       .json(responseHandler(false, 500, 'Server Error', null));
//   }
// });

exports.getSingleTag = asyncHandler(async (req, res) => {
  try {
    await tagsService.retrieveOne(req.params.tagname, (err, data) => {
      if (err) {
        console.log(err);
        return res.status(err.code).json(err);
      }
      return res.status(data.code).json(data);
    });
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json(responseHandler(false, 500, 'Server Error', null));
  }
});
