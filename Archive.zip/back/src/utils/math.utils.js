const getRandomInt = (max = 100) => Math.ceil(Math.random() * max);

module.exports = math = {
  getRandomInt,
};
