const math = require('./math.utils');
const conditional = require('./conditional.utils');
const array = require('./array.utils');

module.exports = {
  math,
  conditional,
  array,
};
